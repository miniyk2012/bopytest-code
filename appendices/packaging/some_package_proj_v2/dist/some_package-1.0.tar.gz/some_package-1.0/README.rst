>> import some_package
>> some_package.some_func()
42
